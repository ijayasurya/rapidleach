<?php
$upload_services[] = 'rioupload.com';
$max_file_size['rioupload.com'] = 2000;
$page_upload['rioupload.com'] = 'rioupload.com.php';  
?>