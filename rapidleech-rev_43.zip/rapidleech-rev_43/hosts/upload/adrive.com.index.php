<?php 
$upload_services[] = "adrive.com";
$max_file_size["adrive.com"] = 2048;
$page_upload["adrive.com"] = "adrive.com.php";  
?>