<?php 
$upload_services[] = "115.com";
$max_file_size["115.com"] = 1024;
$page_upload["115.com"] = "115.com.php";  
?>