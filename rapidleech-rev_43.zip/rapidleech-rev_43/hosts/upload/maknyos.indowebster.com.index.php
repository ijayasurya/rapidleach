<?php
$upload_services[] = 'maknyos.indowebster.com';
$max_file_size['maknyos.indowebster.com'] = 384;
$page_upload['maknyos.indowebster.com'] = 'maknyos.indowebster.com.php';
?>