<?php
$upload_services[]="backup.bz";
$max_file_size["backup.bz"]=5120;
$page_upload["backup.bz"] = "backup.bz.php";  
?>