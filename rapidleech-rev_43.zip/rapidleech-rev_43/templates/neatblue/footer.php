<?php
// You can do something here before finish executing the script
?>
</body>
</html>